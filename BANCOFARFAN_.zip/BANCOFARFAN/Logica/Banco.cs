using BancoSimulador.Entidades;
using BancoSimulador.Estructuras;

namespace BancoSimulador.Logica
{
    /// <summary>
    /// Clase central del sistema bancario.
    /// Coordina las tres estructuras de datos del proyecto:
    ///   - Lista enlazada  → almacena todos los clientes registrados
    ///   - Cola de atención → controla el orden de atención (FIFO)
    ///   - Pila de transacciones → guarda el historial y permite deshacer operaciones (LIFO)
    /// 
    /// Actúa como intermediario entre la interfaz de usuario (Menu.cs) y las estructuras.
    /// Toda la validación de negocio está aquí, no en el menú.
    /// </summary>
    public class Banco
    {
        // Nombre del banco (se muestra en la interfaz)
        public string NombreBanco { get; private set; }

        // Lista enlazada que almacena todos los clientes del banco
        private ListaEnlazadaClientes _clientes;

        // Cola que gestiona el orden de atención presencial
        private ColaAtencion _colaAtencion;

        // Pila que registra todas las transacciones para poder deshacerlas
        private PilaTransacciones _pilaTransacciones;

        /// <summary>
        /// Constructor: inicializa el banco con su nombre y las tres estructuras vacías.
        /// </summary>
        public Banco(string nombreBanco)
        {
            NombreBanco        = nombreBanco;
            _clientes          = new ListaEnlazadaClientes();
            _colaAtencion      = new ColaAtencion();
            _pilaTransacciones = new PilaTransacciones();
        }

        // ─────────────────────────────────────────────
        //  GESTIÓN DE CLIENTES (Lista Enlazada)
        // ─────────────────────────────────────────────

        /// <summary>
        /// Registra un nuevo cliente en la lista enlazada.
        /// Valida: campos no vacíos, saldo no negativo, que no exista duplicado por ID o cuenta.
        /// Retorna una tupla con (éxito: bool, mensaje: string) para informar al menú.
        /// </summary>
        public (bool exito, string mensaje) RegistrarCliente(string id, string nombre, string cuenta, double saldo)
        {
            // Validar que ningún campo obligatorio esté vacío o en blanco
            if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(cuenta))
                return (false, "Todos los campos son obligatorios.");

            // El saldo inicial no puede ser un valor negativo
            if (saldo < 0)
                return (false, "El saldo inicial no puede ser negativo.");

            // Revisar en la lista si ya existe alguien con ese ID o número de cuenta
            if (_clientes.ExisteCliente(id, cuenta))
                return (false, "Ya existe un cliente con esa identificación o número de cuenta.");

            // Crear el objeto Cliente e insertarlo al final de la lista enlazada
            Cliente nuevo = new Cliente(id, nombre, cuenta, saldo);
            _clientes.Insertar(nuevo);

            return (true, $"Cliente '{nombre}' registrado exitosamente.");
        }

        /// <summary>
        /// Busca un cliente en la lista enlazada por su número de identificación.
        /// Retorna el objeto Cliente o null si no existe.
        /// </summary>
        public Cliente BuscarCliente(string identificacion)
        {
            return _clientes.BuscarPorIdentificacion(identificacion);
        }

        /// <summary>
        /// Busca un cliente en la lista enlazada por su número de cuenta.
        /// Retorna el objeto Cliente o null si no existe.
        /// </summary>
        public Cliente BuscarClientePorCuenta(string numeroCuenta)
        {
            return _clientes.BuscarPorNumeroCuenta(numeroCuenta);
        }

        /// <summary>
        /// Recorre la lista enlazada e imprime todos los clientes registrados.
        /// </summary>
        public void ListarClientes()
        {
            _clientes.ListarClientes();
        }

        /// <summary>
        /// Retorna el número total de clientes en la lista.
        /// </summary>
        public int TotalClientes()
        {
            return _clientes.ContarClientes();
        }

        /// <summary>
        /// Retorna la suma del saldo de todos los clientes del banco.
        /// </summary>
        public double TotalDinero()
        {
            return _clientes.TotalDinero();
        }

        // ─────────────────────────────────────────────
        //  COLA DE ATENCIÓN (Cola FIFO)
        // ─────────────────────────────────────────────

        /// <summary>
        /// Agrega un cliente a la cola de atención buscándolo primero en la lista.
        /// Valida: que el cliente exista y que no esté ya en la cola.
        /// Retorna (éxito, mensaje).
        /// </summary>
        public (bool exito, string mensaje) AgregarACola(string identificacion)
        {
            // Verificar que el cliente existe en la lista enlazada
            Cliente cliente = _clientes.BuscarPorIdentificacion(identificacion);

            if (cliente == null)
                return (false, "No existe ningún cliente con esa identificación.");

            // Verificar que no esté ya esperando en la cola
            if (_colaAtencion.EstaEnCola(identificacion))
                return (false, $"El cliente '{cliente.NombreCompleto}' ya está en la cola de atención.");

            // Encolar solo el ID (no el objeto completo) para ahorrar espacio
            _colaAtencion.Encolar(identificacion);

            return (true, $"Cliente '{cliente.NombreCompleto}' agregado a la cola de atención.");
        }

        /// <summary>
        /// Desencola al primer cliente (FIFO) y retorna sus datos completos.
        /// Busca el cliente en la lista usando la identificación guardada en la cola.
        /// Retorna (éxito, mensaje, cliente) — cliente puede ser null si hay error.
        /// </summary>
        public (bool exito, string mensaje, Cliente cliente) AtenderSiguiente()
        {
            if (_colaAtencion.EstaVacia())
                return (false, "No hay clientes en la cola de atención.", null);

            // Sacar el ID del frente de la cola
            string id = _colaAtencion.Desencolar();

            // Buscar los datos completos del cliente en la lista enlazada
            Cliente cliente = _clientes.BuscarPorIdentificacion(id);

            if (cliente == null)
                return (false, "Error: cliente no encontrado en el sistema.", null);

            return (true, $"Atendiendo a: {cliente.NombreCompleto}", cliente);
        }

        /// <summary>
        /// Muestra el contenido actual de la cola de atención con número de turno.
        /// </summary>
        public void MostrarCola()
        {
            _colaAtencion.MostrarCola();
        }

        // ─────────────────────────────────────────────
        //  OPERACIONES BANCARIAS (Pila de transacciones)
        // ─────────────────────────────────────────────

        /// <summary>
        /// Realiza un depósito en la cuenta del cliente indicado.
        /// Guarda el saldo anterior en la transacción para poder deshacer si es necesario.
        /// Apila la transacción en la pila de historial.
        /// Retorna (éxito, mensaje).
        /// </summary>
        public (bool exito, string mensaje) Depositar(string identificacion, double monto)
        {
            // El monto debe ser positivo
            if (monto <= 0)
                return (false, "El monto del depósito debe ser mayor a cero.");

            Cliente cliente = _clientes.BuscarPorIdentificacion(identificacion);
            if (cliente == null)
                return (false, "No existe ningún cliente con esa identificación.");

            double saldoAnterior = cliente.Saldo; // Guardar antes de modificar

            // Crear el registro de la transacción con el estado anterior
            Transaccion transaccion = new Transaccion(cliente.NumeroCuenta, TipoTransaccion.Deposito, monto, saldoAnterior);

            cliente.Saldo += monto;               // Actualizar el saldo del cliente
            _pilaTransacciones.Apilar(transaccion); // Registrar en la pila

            return (true, $"Deposito de {monto:F2} $ realizado. Nuevo saldo: {cliente.Saldo:F2} $");
        }

        /// <summary>
        /// Realiza un retiro de la cuenta del cliente indicado.
        /// Valida que haya saldo suficiente antes de proceder.
        /// Apila la transacción para poder deshacerla.
        /// Retorna (éxito, mensaje).
        /// </summary>
        public (bool exito, string mensaje) Retirar(string identificacion, double monto)
        {
            // El monto debe ser positivo
            if (monto <= 0)
                return (false, "El monto del retiro debe ser mayor a cero.");

            Cliente cliente = _clientes.BuscarPorIdentificacion(identificacion);
            if (cliente == null)
                return (false, "No existe ningún cliente con esa identificación.");

            // No se puede retirar más de lo que hay en la cuenta
            if (monto > cliente.Saldo)
                return (false, $"Saldo insuficiente. Saldo disponible: {cliente.Saldo:F2} $");

            double saldoAnterior = cliente.Saldo; // Guardar antes de modificar

            // Crear el registro con el estado antes del retiro
            Transaccion transaccion = new Transaccion(cliente.NumeroCuenta, TipoTransaccion.Retiro, monto, saldoAnterior);

            cliente.Saldo -= monto;               // Descontar el monto
            _pilaTransacciones.Apilar(transaccion); // Registrar en la pila

            return (true, $"Retiro de {monto:F2} $ realizado. Nuevo saldo: {cliente.Saldo:F2} $");
        }

        /// <summary>
        /// Consulta el saldo actual de un cliente sin modificarlo.
        /// Retorna (éxito, mensaje, saldo) — saldo es 0 si no se encuentra el cliente.
        /// </summary>
        public (bool exito, string mensaje, double saldo) ConsultarSaldo(string identificacion)
        {
            Cliente cliente = _clientes.BuscarPorIdentificacion(identificacion);
            if (cliente == null)
                return (false, "No existe ningún cliente con esa identificación.", 0);

            return (true, $"Saldo de {cliente.NombreCompleto} (Cuenta {cliente.NumeroCuenta})", cliente.Saldo);
        }

        // ─────────────────────────────────────────────
        //  REVERSIÓN DE OPERACIONES (Pila LIFO)
        // ─────────────────────────────────────────────

        /// <summary>
        /// Deshace la última transacción registrada usando la pila (pop + restaurar).
        /// Saca la transacción de la cima, busca al cliente por número de cuenta
        /// y restaura su saldo al valor guardado en SaldoAnterior.
        /// Retorna (éxito, mensaje).
        /// </summary>
        public (bool exito, string mensaje) DeshacerUltimaTransaccion()
        {
            if (_pilaTransacciones.EstaVacia())
                return (false, "No hay transacciones para deshacer.");

            // Desapilar la transacción más reciente (tope de la pila)
            Transaccion ultima = _pilaTransacciones.Desapilar();

            // Buscar al cliente usando el número de cuenta de la transacción
            Cliente cliente = _clientes.BuscarPorNumeroCuenta(ultima.NumeroCuenta);

            if (cliente == null)
                return (false, "Error: no se encontró la cuenta asociada a la transacción.");

            // Restaurar el saldo al estado previo a esa transacción
            cliente.Saldo = ultima.SaldoAnterior;

            string tipo = ultima.Tipo == TipoTransaccion.Deposito ? "depósito" : "retiro";
            return (true,
                $"Se deshizo el {tipo} de {ultima.Monto:F2} $ en la cuenta {ultima.NumeroCuenta}.\n" +
                $"  Saldo restaurado a: {cliente.Saldo:F2} $");
        }
    }
}
