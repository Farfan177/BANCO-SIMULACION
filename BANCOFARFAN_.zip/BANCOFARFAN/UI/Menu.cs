using BancoSimulador.Entidades;
using BancoSimulador.Logica;

namespace BancoSimulador.UI
{
    /// <summary>
    /// Clase encargada de toda la interacción con el usuario por consola.
    /// Muestra el menú principal y llama a los métodos correspondientes
    /// según la opción que el usuario seleccione.
    /// </summary>
    public class Menu
    {
        // Referencia al objeto Banco que contiene toda la lógica y las estructuras de datos
        private Banco _banco;

        /// <summary>
        /// Constructor: recibe el banco ya inicializado desde Program.cs
        /// </summary>
        public Menu(Banco banco)
        {
            _banco = banco;
        }

        // ─────────────────────────────────────────────
        //  MENÚ PRINCIPAL
        // ─────────────────────────────────────────────

        /// <summary>
        /// Método principal que inicia el bucle del menú.
        /// Se ejecuta en un while hasta que el usuario elija salir.
        /// </summary>
        public void Ejecutar()
        {
            MostrarBienvenida();

            bool salir = false;
            while (!salir)
            {
                MostrarMenuPrincipal();
                // Leer la opción del usuario y limpiar espacios
                string opcion = (Console.ReadLine() ?? string.Empty).Trim();

                // Redirigir a la función correspondiente según la opción ingresada
                switch (opcion)
                {
                    case "1":  RegistrarCliente();       break;
                    case "2":  ListarClientes();         break;
                    case "3":  BuscarCliente();          break;
                    case "4":  AgregarACola();           break;
                    case "5":  AtenderSiguiente();       break;
                    case "6":  MostrarCola();            break;
                    case "7":  Depositar();              break;
                    case "8":  Retirar();                break;
                    case "9":  ConsultarSaldo();         break;
                    case "10": DeshacerTransaccion();    break;
                    case "11": MostrarTotalClientes();   break;
                    case "12": MostrarTotalDinero();     break;
                    case "13": salir = ConfirmarSalida(); break;
                    default:
                        // Mensaje de error para opción fuera de rango
                        MostrarMensaje("Opcion invalida. Por favor ingrese un numero del 1 al 13.");
                        break;
                }

                // Después de cada acción, pausar para que el usuario pueda leer el resultado
                if (!salir)
                {
                    Console.WriteLine();
                    Console.Write("  Presione ENTER para continuar...");
                    Console.ReadLine();
                }
            }

            MostrarDespedida();
        }

        // ─────────────────────────────────────────────
        //  PRESENTACIÓN VISUAL
        // ─────────────────────────────────────────────

        /// <summary>
        /// Pantalla de bienvenida que aparece al iniciar el programa.
        /// </summary>
        private void MostrarBienvenida()
        {
            Console.Clear();
            Console.WriteLine("╔══════════════════════════════════════════════════════╗");
            Console.WriteLine($"║             BIENVENIDO AL {_banco.NombreBanco,-27}║");
            Console.WriteLine("║              ¡SIEMPRE PARA SERVIRTE!                 ║");
            Console.WriteLine("╚══════════════════════════════════════════════════════╝");
            Console.WriteLine();
            Console.Write("  Presione ENTER para continuar...");
            Console.ReadLine();
        }

        /// <summary>
        /// Dibuja el menú principal con todas las opciones disponibles.
        /// Se muestra al inicio de cada iteración del bucle principal.
        /// </summary>
        private void MostrarMenuPrincipal()
        {
            Console.Clear();
            Console.WriteLine("╔══════════════════════════════════════════════════════╗");
            Console.WriteLine($"║            {_banco.NombreBanco,-42}║");
            Console.WriteLine("╠══════════════════════════════════════════════════════╣");
            Console.WriteLine("║                   GESTION DE CLIENTES                ║");
            Console.WriteLine("║   1. Registrar cliente                               ║");
            Console.WriteLine("║   2. Listar clientes                                 ║");
            Console.WriteLine("║   3. Buscar cliente                                  ║");
            Console.WriteLine("╠══════════════════════════════════════════════════════╣");
            Console.WriteLine("║                    COLA DE ATENCION                  ║");
            Console.WriteLine("║   4. Agregar cliente a la cola                       ║");
            Console.WriteLine("║   5. Atender siguiente cliente                       ║");
            Console.WriteLine("║   6. Mostrar cola de atencion                        ║");
            Console.WriteLine("╠══════════════════════════════════════════════════════╣");
            Console.WriteLine("║                  OPERACIONES BANCARIAS               ║");
            Console.WriteLine("║   7. Realizar deposito                               ║");
            Console.WriteLine("║   8. Realizar retiro                                 ║");
            Console.WriteLine("║   9. Consultar saldo                                 ║");
            Console.WriteLine("║  10. Deshacer ultima transaccion                     ║");
            Console.WriteLine("╠══════════════════════════════════════════════════════╣");
            Console.WriteLine("║                   INFORMACION GENERAL                ║");
            Console.WriteLine("║  11. Mostrar total de clientes                       ║");
            Console.WriteLine("║  12. Mostrar total de dinero del banco               ║");
            Console.WriteLine("╠══════════════════════════════════════════════════════╣");
            Console.WriteLine("║  13. Salir                                           ║");
            Console.WriteLine("╚══════════════════════════════════════════════════════╝");
            Console.Write("\n  Seleccione una opcion: ");
        }

        /// <summary>
        /// Limpia la pantalla y dibuja un encabezado de sección con el título recibido.
        /// Se llama al inicio de cada opción del menú.
        /// </summary>
        private void MostrarEncabezado(string titulo)
        {
            Console.Clear();
            Console.WriteLine($"\n  ══════════════════════════════════");
            Console.WriteLine($"   {titulo}");
            Console.WriteLine($"  ══════════════════════════════════\n");
        }

        /// <summary>
        /// Muestra un mensaje con el prefijo ">>" para destacarlo visualmente.
        /// Se usa para mostrar resultados, errores o confirmaciones.
        /// </summary>
        private void MostrarMensaje(string mensaje)
        {
            Console.WriteLine($"\n  >> {mensaje}");
        }

        // ─────────────────────────────────────────────
        //  HELPERS DE LECTURA SEGURA
        // ─────────────────────────────────────────────

        /// <summary>
        /// Lee un campo que solo debe contener dígitos (cédula, número de cuenta).
        /// Si el usuario ingresa letras u otros caracteres, muestra un error
        /// y le da la opción de reintentar o cancelar.
        /// Retorna null si el usuario decide cancelar.
        /// </summary>
        private string? LeerSoloNumeros(string etiqueta)
        {
            while (true)
            {
                Console.Write($"  {etiqueta}: ");
                string valor = (Console.ReadLine() ?? string.Empty).Trim();

                // Verificar que el campo no esté vacío y que todos sus caracteres sean dígitos
                if (valor.Length > 0 && valor.All(char.IsDigit))
                    return valor; // Valor válido: retornarlo

                // Si llegamos aquí, el valor no es solo numérico
                Console.WriteLine("\n  >> ERROR: Este campo solo acepta valores numericos (sin letras ni simbolos).");
                Console.Write("  ¿Desea intentarlo de nuevo? (s/n): ");
                string respuesta = (Console.ReadLine() ?? string.Empty).Trim().ToLower();

                // Si el usuario no quiere reintentar, cancelar la operación
                if (respuesta != "s" && respuesta != "si")
                    return null;

                Console.WriteLine(); // Línea en blanco para separar el reintento
            }
        }

        /// <summary>
        /// Lee un monto numérico (decimal) del usuario.
        /// Retorna false si el valor no se puede convertir a número.
        /// </summary>
        private bool LeerMonto(string etiqueta, out double monto)
        {
            Console.Write($"  {etiqueta}: ");
            string montoStr = (Console.ReadLine() ?? string.Empty).Trim();

            // double.TryParse intenta convertir el texto a número decimal
            if (!double.TryParse(montoStr, out monto))
            {
                MostrarMensaje("El monto ingresado no es valido. Debe ser un numero.");
                return false;
            }
            return true;
        }

        // ─────────────────────────────────────────────
        //  OPCIONES DEL MENÚ — GESTIÓN DE CLIENTES
        // ─────────────────────────────────────────────

        /// <summary>
        /// Opción 1: Registrar un nuevo cliente en el sistema.
        /// Valida que cédula y número de cuenta sean solo numéricos.
        /// Si el usuario cancela algún campo numérico, se aborta el registro.
        /// </summary>
        private void RegistrarCliente()
        {
            MostrarEncabezado("REGISTRAR NUEVO CLIENTE");

            // Leer cédula: solo números. LeerSoloNumeros retorna null si el usuario cancela
            string? id = LeerSoloNumeros("Ingrese identificacion (cedula)");
            if (id == null)
            {
                MostrarMensaje("Registro cancelado.");
                return;
            }

            // Leer nombre completo (puede tener letras, espacios, etc.)
            Console.Write("  Ingrese nombre completo: ");
            string nombre = (Console.ReadLine() ?? string.Empty).Trim();

            // Leer número de cuenta: solo números
            string? cuenta = LeerSoloNumeros("Ingrese numero de cuenta");
            if (cuenta == null)
            {
                MostrarMensaje("Registro cancelado.");
                return;
            }

            // Leer saldo inicial como valor decimal
            if (!LeerMonto("Ingrese saldo inicial", out double saldo))
                return;

            // Enviar los datos a la lógica del banco para registrar al cliente
            var (exito, mensaje) = _banco.RegistrarCliente(id, nombre, cuenta, saldo);
            MostrarMensaje(mensaje);
        }

        /// <summary>
        /// Opción 2: Listar todos los clientes registrados con su información.
        /// </summary>
        private void ListarClientes()
        {
            MostrarEncabezado("LISTADO DE CLIENTES REGISTRADOS");
            _banco.ListarClientes(); // Recorre la lista enlazada y los imprime
            Console.WriteLine($"\n  Total de clientes: {_banco.TotalClientes()}");
        }

        /// <summary>
        /// Opción 3: Buscar un cliente por cédula y mostrar su información.
        /// Después de encontrarlo, ofrece un submenú para:
        ///   - Agregar al cliente a la cola de atención
        ///   - Realizar un depósito
        ///   - Realizar un retiro
        /// </summary>
        private void BuscarCliente()
        {
            MostrarEncabezado("BUSCAR CLIENTE");
            Console.Write("  Ingrese la identificacion del cliente: ");
            string id = (Console.ReadLine() ?? string.Empty).Trim();

            Cliente? cliente = _banco.BuscarCliente(id);

            if (cliente == null)
            {
                MostrarMensaje("No se encontro ningun cliente con esa identificacion.");
                return;
            }

            // Mostrar los datos del cliente encontrado
            MostrarMensaje("Cliente encontrado:");
            Console.WriteLine($"\n{cliente}");

            // ── Submenú de acciones sobre el cliente encontrado ──
            Console.WriteLine("\n  ¿Que desea hacer con este cliente?");
            Console.WriteLine("    1. Agregar a la cola de atencion");
            Console.WriteLine("    2. Realizar un deposito");
            Console.WriteLine("    3. Realizar un retiro");
            Console.WriteLine("    0. Volver al menu principal");
            Console.Write("\n  Seleccione una opcion: ");

            string subOpcion = (Console.ReadLine() ?? string.Empty).Trim();

            switch (subOpcion)
            {
                case "1":
                    // Encolar directamente usando el ID ya conocido
                    var (exito1, msg1) = _banco.AgregarACola(id);
                    MostrarMensaje(msg1);
                    break;

                case "2":
                    // Pedir el monto y hacer un depósito al cliente encontrado
                    if (!LeerMonto("Ingrese el monto a depositar", out double montoDeposito))
                        return;
                    var (exito2, msg2) = _banco.Depositar(id, montoDeposito);
                    MostrarMensaje(msg2);
                    break;

                case "3":
                    // Pedir el monto y hacer un retiro al cliente encontrado
                    if (!LeerMonto("Ingrese el monto a retirar", out double montoRetiro))
                        return;
                    var (exito3, msg3) = _banco.Retirar(id, montoRetiro);
                    MostrarMensaje(msg3);
                    break;

                case "0":
                    // El usuario decidió no hacer nada, simplemente volver
                    break;

                default:
                    MostrarMensaje("Opcion no valida. Volviendo al menu principal.");
                    break;
            }
        }

        // ─────────────────────────────────────────────
        //  OPCIONES DEL MENÚ — COLA DE ATENCIÓN
        // ─────────────────────────────────────────────

        /// <summary>
        /// Opción 4: Agregar un cliente a la cola de atención ingresando su cédula.
        /// </summary>
        private void AgregarACola()
        {
            MostrarEncabezado("AGREGAR CLIENTE A COLA DE ATENCION");
            Console.Write("  Ingrese la identificacion del cliente: ");
            string id = (Console.ReadLine() ?? string.Empty).Trim();

            // El banco valida que el cliente exista y que no esté ya en la cola
            var (exito, mensaje) = _banco.AgregarACola(id);
            MostrarMensaje(mensaje);
        }

        /// <summary>
        /// Opción 5: Atiende al siguiente cliente de la cola (lo desencola).
        /// Después de mostrar su información, ofrece un submenú para:
        ///   - Realizar un depósito
        ///   - Realizar un retiro
        /// </summary>
        private void AtenderSiguiente()
        {
            MostrarEncabezado("ATENDER SIGUIENTE CLIENTE");

            // Desencolar al primero en la cola y obtener sus datos
            var (exito, mensaje, cliente) = _banco.AtenderSiguiente();
            MostrarMensaje(mensaje);

            if (!exito || cliente == null)
                return; // No había nadie en la cola o hubo un error

            // Mostrar los datos del cliente que está siendo atendido
            Console.WriteLine($"\n{cliente}");

            // ── Submenú de operaciones durante la atención ──
            Console.WriteLine("\n  ¿Que operacion desea realizar?");
            Console.WriteLine("    1. Realizar un deposito");
            Console.WriteLine("    2. Realizar un retiro");
            Console.WriteLine("    0. Solo registrar la atencion (sin operacion)");
            Console.Write("\n  Seleccione una opcion: ");

            string subOpcion = (Console.ReadLine() ?? string.Empty).Trim();

            switch (subOpcion)
            {
                case "1":
                    // Depósito durante la atención, usando el ID del cliente ya desencolado
                    if (!LeerMonto("Ingrese el monto a depositar", out double montoDeposito))
                        return;
                    var (ex1, msg1) = _banco.Depositar(cliente.Identificacion, montoDeposito);
                    MostrarMensaje(msg1);
                    break;

                case "2":
                    // Retiro durante la atención
                    if (!LeerMonto("Ingrese el monto a retirar", out double montoRetiro))
                        return;
                    var (ex2, msg2) = _banco.Retirar(cliente.Identificacion, montoRetiro);
                    MostrarMensaje(msg2);
                    break;

                case "0":
                    // Atención registrada sin operación bancaria
                    MostrarMensaje("Atencion registrada sin operacion bancaria.");
                    break;

                default:
                    MostrarMensaje("Opcion no valida. Atencion registrada sin operacion.");
                    break;
            }
        }

        // ─────────────────────────────────────────────
        //  OPCIONES DEL MENÚ — OPERACIONES BANCARIAS
        // ─────────────────────────────────────────────

        /// <summary>
        /// Opción 7: Realizar un depósito directo a un cliente (sin pasar por cola).
        /// </summary>
        private void Depositar()
        {
            MostrarEncabezado("REALIZAR DEPOSITO");
            Console.Write("  Ingrese la identificacion del cliente: ");
            string id = (Console.ReadLine() ?? string.Empty).Trim();

            // Leer el monto y validar que sea un número
            if (!LeerMonto("Ingrese el monto a depositar", out double monto))
                return;

            // El banco valida que el monto sea positivo y que el cliente exista
            var (exito, mensaje) = _banco.Depositar(id, monto);
            MostrarMensaje(mensaje);
        }

        /// <summary>
        /// Opción 8: Realizar un retiro directo a un cliente (sin pasar por cola).
        /// </summary>
        private void Retirar()
        {
            MostrarEncabezado("REALIZAR RETIRO");
            Console.Write("  Ingrese la identificacion del cliente: ");
            string id = (Console.ReadLine() ?? string.Empty).Trim();

            // Leer el monto y validar que sea un número
            if (!LeerMonto("Ingrese el monto a retirar", out double monto))
                return;

            // El banco valida saldo suficiente, monto positivo y que el cliente exista
            var (exito, mensaje) = _banco.Retirar(id, monto);
            MostrarMensaje(mensaje);
        }

        /// <summary>
        /// Opción 9: Consultar el saldo actual de un cliente.
        /// </summary>
        private void ConsultarSaldo()
        {
            MostrarEncabezado("CONSULTAR SALDO");
            Console.Write("  Ingrese la identificacion del cliente: ");
            string id = (Console.ReadLine() ?? string.Empty).Trim();

            // El banco retorna el saldo como tercer elemento de la tupla
            var (exito, mensaje, saldo) = _banco.ConsultarSaldo(id);
            MostrarMensaje(mensaje);

            // Solo mostrar el saldo si la consulta fue exitosa
            if (exito)
                Console.WriteLine($"\n  Saldo actual: {saldo:F2} $");
        }

        /// <summary>
        /// Opción 10: Deshacer la última transacción registrada en la pila.
        /// Restaura el saldo del cliente al valor que tenía antes de esa operación.
        /// </summary>
        private void DeshacerTransaccion()
        {
            MostrarEncabezado("DESHACER ULTIMA TRANSACCION");

            // El banco desapila la última transacción y restaura el saldo anterior
            var (exito, mensaje) = _banco.DeshacerUltimaTransaccion();
            MostrarMensaje(mensaje);
        }

        // ─────────────────────────────────────────────
        //  OPCIONES DEL MENÚ — INFORMACIÓN GENERAL
        // ─────────────────────────────────────────────

        /// <summary>
        /// Opción 6: Mostrar todos los clientes actualmente en la cola de atención.
        /// </summary>
        private void MostrarCola()
        {
            MostrarEncabezado("COLA DE ATENCION ACTUAL");
            _banco.MostrarCola(); // Recorre la cola de frente a fin y los imprime con turno
        }

        /// <summary>
        /// Opción 11: Mostrar el conteo total de clientes registrados.
        /// </summary>
        private void MostrarTotalClientes()
        {
            MostrarEncabezado("TOTAL DE CLIENTES");
            Console.WriteLine($"  Clientes registrados en el banco: {_banco.TotalClientes()}");
        }

        /// <summary>
        /// Opción 12: Mostrar la suma total del dinero en todas las cuentas del banco.
        /// </summary>
        private void MostrarTotalDinero()
        {
            MostrarEncabezado("TOTAL DE DINERO EN EL BANCO");
            Console.WriteLine($"  Total de dinero almacenado en cuentas: {_banco.TotalDinero():F2} $");
        }

        // ─────────────────────────────────────────────
        //  SALIDA DEL PROGRAMA
        // ─────────────────────────────────────────────

        /// <summary>
        /// Opción 13: Confirmar si el usuario desea salir del sistema.
        /// Retorna true si confirma con "s" o "si", false en caso contrario.
        /// </summary>
        private bool ConfirmarSalida()
        {
            Console.Write("\n  Esta seguro que desea salir? (s/n): ");
            string respuesta = (Console.ReadLine() ?? string.Empty).Trim().ToLower();
            return respuesta == "s" || respuesta == "si";
        }

        /// <summary>
        /// Pantalla de despedida que se muestra al cerrar el sistema.
        /// </summary>
        private void MostrarDespedida()
        {
            Console.Clear();
            Console.WriteLine("\n╔══════════════════════════════════════════════╗");
            Console.WriteLine($"║  Gracias por usar el {_banco.NombreBanco,-24}║");
            Console.WriteLine("║                ¡Hasta pronto!               ║");
            Console.WriteLine("╚══════════════════════════════════════════════╝\n");
        }
    }
}
