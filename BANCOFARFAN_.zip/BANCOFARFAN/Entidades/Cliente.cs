namespace BancoSimulador.Entidades
{
    /// <summary>
    /// Representa un cliente del banco con sus datos personales y bancarios.
    /// Es la unidad de información que se guarda en cada nodo de la lista enlazada.
    /// </summary>
    public class Cliente
    {
        // Cédula o número de identificación único del cliente
        public string Identificacion { get; set; }

        // Nombre y apellido del cliente
        public string NombreCompleto { get; set; }

        // Número de cuenta bancaria único del cliente
        public string NumeroCuenta { get; set; }

        // Saldo actual de la cuenta (se actualiza en depósitos y retiros)
        public double Saldo { get; set; }

        /// <summary>
        /// Constructor: inicializa todos los campos del cliente al momento de crearlo.
        /// </summary>
        public Cliente(string identificacion, string nombreCompleto, string numeroCuenta, double saldoInicial)
        {
            Identificacion  = identificacion;
            NombreCompleto  = nombreCompleto;
            NumeroCuenta    = numeroCuenta;
            Saldo           = saldoInicial;
        }

        /// <summary>
        /// Representación en texto del cliente.
        /// Se usa al imprimir un objeto Cliente directamente con Console.WriteLine.
        /// </summary>
        public override string ToString()
        {
            return $"  ID: {Identificacion} | Nombre: {NombreCompleto} | Cuenta: {NumeroCuenta} | Saldo: {Saldo:F2} $";
        }
    }
}
