namespace BancoSimulador.Entidades
{
    /// <summary>
    /// Enumeración que define los dos únicos tipos de transacción posibles en el sistema.
    /// Se usa para identificar qué operación se hizo al deshacer o mostrar historial.
    /// </summary>
    public enum TipoTransaccion
    {
        Deposito,  // El cliente ingresó dinero a su cuenta
        Retiro     // El cliente sacó dinero de su cuenta
    }

    /// <summary>
    /// Representa una operación bancaria registrada en el historial.
    /// Cada transacción se guarda en la pila para poder deshacerla después.
    /// Almacena el estado ANTERIOR al cambio para poder restaurarlo si se deshace.
    /// </summary>
    public class Transaccion
    {
        // Número de cuenta sobre la que se hizo la operación
        public string NumeroCuenta { get; set; }

        // Indica si fue un depósito o un retiro
        public TipoTransaccion Tipo { get; set; }

        // Cantidad de dinero que se movió
        public double Monto { get; set; }

        // Saldo que tenía el cliente ANTES de esta transacción (sirve para deshacer)
        public double SaldoAnterior { get; set; }

        // Fecha y hora exacta en que se realizó la operación
        public DateTime FechaHora { get; set; }

        /// <summary>
        /// Constructor: guarda todos los datos de la operación.
        /// La fecha y hora se captura automáticamente con DateTime.Now.
        /// </summary>
        public Transaccion(string numeroCuenta, TipoTransaccion tipo, double monto, double saldoAnterior)
        {
            NumeroCuenta  = numeroCuenta;
            Tipo          = tipo;
            Monto         = monto;
            SaldoAnterior = saldoAnterior;
            FechaHora     = DateTime.Now; // Captura el momento exacto de la transacción
        }

        /// <summary>
        /// Representación en texto de la transacción para mostrarse en consola.
        /// Convierte el enum a un texto legible (DEPÓSITO / RETIRO).
        /// </summary>
        public override string ToString()
        {
            string tipoStr = Tipo == TipoTransaccion.Deposito ? "DEPÓSITO" : "RETIRO";
            return $"  [{tipoStr}] Cuenta: {NumeroCuenta} | Monto: {Monto:F2} $ | Saldo anterior: {SaldoAnterior:F2} $ | Fecha: {FechaHora:dd/MM/yyyy HH:mm:ss}";
        }
    }
}
