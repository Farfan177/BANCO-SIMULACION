namespace BancoSimulador.Estructuras
{
    /// <summary>
    /// Cola de atención implementada manualmente con nodos enlazados (FIFO).
    /// FIFO = First In, First Out: el primero en llegar es el primero en ser atendido.
    /// 
    /// Estructura interna:
    ///   _frente → [nodo1] → [nodo2] → [nodo3] ← _fin
    /// 
    /// - Encolar agrega al _fin (al final de la fila)
    /// - Desencolar retira del _frente (del inicio de la fila)
    /// </summary>
    public class ColaAtencion
    {
        // Apunta al primer nodo de la cola (el siguiente en ser atendido)
        private NodoCola _frente;

        // Apunta al último nodo de la cola (el recién llegado)
        private NodoCola _fin;

        /// <summary>
        /// Constructor: la cola empieza vacía, ambos punteros en null.
        /// </summary>
        public ColaAtencion()
        {
            _frente = null;
            _fin    = null;
        }

        /// <summary>
        /// Agrega un cliente al FINAL de la cola (encolar / enqueue).
        /// Si la cola está vacía, el nuevo nodo es tanto frente como fin.
        /// Si ya hay nodos, se enlaza al final y se actualiza _fin.
        /// </summary>
        public void Encolar(string identificacionCliente)
        {
            NodoCola nuevo = new NodoCola(identificacionCliente);

            if (_fin == null)
            {
                // La cola estaba vacía: el único nodo es frente y fin al mismo tiempo
                _frente = nuevo;
                _fin    = nuevo;
            }
            else
            {
                // Ya hay nodos: enlazar el nuevo al final y mover _fin
                _fin.Siguiente = nuevo;
                _fin           = nuevo;
            }
        }

        /// <summary>
        /// Retira y retorna la identificación del PRIMER cliente de la cola (desencolar / dequeue).
        /// Si después de retirar la cola queda vacía, también resetea _fin a null.
        /// Retorna null si la cola estaba vacía.
        /// </summary>
        public string Desencolar()
        {
            if (_frente == null)
                return null; // La cola estaba vacía, nada que retirar

            // Guardar el ID del frente antes de avanzar el puntero
            string identificacion = _frente.IdentificacionCliente;
            _frente               = _frente.Siguiente; // Mover el frente al siguiente nodo

            // Si al avanzar el frente quedó en null, la cola quedó vacía: limpiar _fin también
            if (_frente == null)
                _fin = null;

            return identificacion;
        }

        /// <summary>
        /// Consulta la identificación del PRIMER cliente sin sacarlo de la cola (peek).
        /// Retorna null si la cola está vacía.
        /// El operador ?. evita un NullReferenceException si _frente es null.
        /// </summary>
        public string VerSiguiente()
        {
            return _frente?.IdentificacionCliente;
        }

        /// <summary>
        /// Recorre toda la cola verificando si una identificación ya está registrada.
        /// Impide que el mismo cliente entre dos veces a la fila.
        /// </summary>
        public bool EstaEnCola(string identificacionCliente)
        {
            NodoCola actual = _frente;
            while (actual != null)
            {
                if (actual.IdentificacionCliente == identificacionCliente)
                    return true; // Encontrado: ya está en la cola
                actual = actual.Siguiente;
            }
            return false; // Recorrió toda la cola sin encontrarlo
        }

        /// <summary>
        /// Imprime en consola todos los clientes en la cola, en orden de atención.
        /// Marca al primero de la fila con la etiqueta "← SIGUIENTE".
        /// </summary>
        public void MostrarCola()
        {
            if (_frente == null)
            {
                Console.WriteLine("  La cola de atención está vacía.");
                return;
            }

            NodoCola actual = _frente;
            int turno = 1;
            while (actual != null)
            {
                // Solo el primer turno recibe la etiqueta especial
                string etiqueta = turno == 1 ? " ← SIGUIENTE" : "";
                Console.WriteLine($"  Turno {turno}: ID {actual.IdentificacionCliente}{etiqueta}");
                actual = actual.Siguiente;
                turno++;
            }
        }

        /// <summary>
        /// Indica si la cola no tiene ningún cliente esperando.
        /// </summary>
        public bool EstaVacia()
        {
            return _frente == null;
        }
    }
}
