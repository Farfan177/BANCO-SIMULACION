using BancoSimulador.Entidades;

namespace BancoSimulador.Estructuras
{
    /// <summary>
    /// Nodo de la lista enlazada de clientes.
    /// Cada nodo almacena un cliente y apunta al siguiente nodo de la cadena.
    /// Cuando Siguiente es null, significa que es el último nodo de la lista.
    /// </summary>
    public class NodoCliente
    {
        // El cliente que este nodo contiene (el "dato" del nodo)
        public Cliente Dato { get; set; }

        // Referencia al siguiente nodo en la lista. null si es el último
        public NodoCliente Siguiente { get; set; }

        /// <summary>
        /// Constructor: crea un nodo con el cliente dado.
        /// Siguiente se inicializa en null porque el nodo aún no está enlazado.
        /// </summary>
        public NodoCliente(Cliente cliente)
        {
            Dato      = cliente;
            Siguiente = null;
        }
    }
}
