using BancoSimulador.Entidades;

namespace BancoSimulador.Estructuras
{
    /// <summary>
    /// Nodo de la pila de transacciones.
    /// Guarda una transacción y apunta al nodo que estaba debajo en la pila.
    /// La pila crece hacia arriba: el último en entrar (cima) apunta hacia abajo.
    /// </summary>
    public class NodoPila
    {
        // La transacción que este nodo almacena
        public Transaccion Dato { get; set; }

        // Referencia al nodo anterior en la pila (el que estaba antes de este)
        // null si este nodo es el fondo de la pila
        public NodoPila Siguiente { get; set; }

        /// <summary>
        /// Constructor: crea un nodo con la transacción dada.
        /// Siguiente se asigna después al momento de apilar.
        /// </summary>
        public NodoPila(Transaccion transaccion)
        {
            Dato      = transaccion;
            Siguiente = null;
        }
    }
}
