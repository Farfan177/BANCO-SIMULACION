namespace BancoSimulador.Estructuras
{
    /// <summary>
    /// Nodo de la cola de atención.
    /// Solo guarda la identificación (cédula) del cliente, no el objeto completo.
    /// Para obtener los datos del cliente se busca en la lista enlazada usando ese ID.
    /// </summary>
    public class NodoCola
    {
        // Cédula del cliente que ocupa este turno en la cola
        public string IdentificacionCliente { get; set; }

        // Referencia al siguiente nodo de la cola. null si es el último en espera
        public NodoCola Siguiente { get; set; }

        /// <summary>
        /// Constructor: crea un nodo de cola con la identificación dada.
        /// Siguiente arranca en null hasta que se encole alguien después.
        /// </summary>
        public NodoCola(string identificacionCliente)
        {
            IdentificacionCliente = identificacionCliente;
            Siguiente             = null;
        }
    }
}
