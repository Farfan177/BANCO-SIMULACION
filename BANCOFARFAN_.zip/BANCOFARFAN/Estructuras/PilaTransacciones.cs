using BancoSimulador.Entidades;

namespace BancoSimulador.Estructuras
{
    /// <summary>
    /// Pila de transacciones implementada manualmente con nodos enlazados (LIFO).
    /// LIFO = Last In, First Out: la última transacción registrada es la primera en deshacerse.
    /// 
    /// Estructura:
    ///   _cima → [transacción más reciente]
    ///               ↓
    ///           [transacción anterior]
    ///               ↓
    ///           [transacción más antigua] → null
    /// 
    /// - Apilar agrega en la cima (encima de todo)
    /// - Desapilar retira de la cima (la más reciente)
    /// </summary>
    public class PilaTransacciones
    {
        // Apunta a la transacción más reciente (tope/cima de la pila)
        private NodoPila _cima;

        /// <summary>
        /// Constructor: la pila empieza vacía (_cima en null).
        /// </summary>
        public PilaTransacciones()
        {
            _cima = null;
        }

        /// <summary>
        /// Apila una nueva transacción encima de las existentes (push).
        /// El nuevo nodo apunta hacia la cima actual, y luego se convierte en la nueva cima.
        /// </summary>
        public void Apilar(Transaccion transaccion)
        {
            NodoPila nuevo = new NodoPila(transaccion);
            nuevo.Siguiente = _cima; // El nuevo nodo "empuja" a la cima actual hacia abajo
            _cima           = nuevo; // El nuevo nodo es ahora la cima
        }

        /// <summary>
        /// Retira y retorna la transacción más reciente de la pila (pop).
        /// La cima pasa a ser el nodo que estaba inmediatamente debajo.
        /// Retorna null si la pila está vacía.
        /// </summary>
        public Transaccion Desapilar()
        {
            if (_cima == null)
                return null; // Pila vacía, nada que sacar

            Transaccion transaccion = _cima.Dato; // Guardar la transacción de la cima
            _cima = _cima.Siguiente;              // Bajar la cima al nodo anterior
            return transaccion;
        }

        /// <summary>
        /// Consulta la transacción más reciente SIN sacarla de la pila (peek).
        /// Útil para ver qué se desharía sin comprometerse a hacerlo.
        /// El operador ?. evita NullReferenceException si _cima es null.
        /// </summary>
        public Transaccion ConsultarUltima()
        {
            return _cima?.Dato;
        }

        /// <summary>
        /// Indica si la pila no tiene ninguna transacción registrada.
        /// </summary>
        public bool EstaVacia()
        {
            return _cima == null;
        }
    }
}
