using BancoSimulador.Entidades;

namespace BancoSimulador.Estructuras
{
    /// <summary>
    /// Lista enlazada simple implementada manualmente para gestionar clientes.
    /// Cada nodo contiene un Cliente y un puntero al siguiente.
    /// 
    /// Estructura:
    ///   _cabeza → [nodo1] → [nodo2] → [nodo3] → null
    /// 
    /// No usa arreglos ni List<T> de C#; los elementos están enlazados por referencia.
    /// </summary>
    public class ListaEnlazadaClientes
    {
        // Puntero al primer nodo de la lista. null si la lista está vacía
        private NodoCliente _cabeza;

        /// <summary>
        /// Constructor: la lista empieza vacía (_cabeza en null).
        /// </summary>
        public ListaEnlazadaClientes()
        {
            _cabeza = null;
        }

        /// <summary>
        /// Inserta un nuevo cliente al FINAL de la lista.
        /// Si la lista está vacía, el nuevo nodo se convierte en la cabeza.
        /// Si ya hay nodos, recorre hasta el último y enlaza el nuevo al final.
        /// </summary>
        public void Insertar(Cliente cliente)
        {
            NodoCliente nuevo = new NodoCliente(cliente);

            if (_cabeza == null)
            {
                // Lista vacía: el nuevo nodo es el primero y único
                _cabeza = nuevo;
                return;
            }

            // Recorrer hasta el último nodo (el que tiene Siguiente == null)
            NodoCliente actual = _cabeza;
            while (actual.Siguiente != null)
            {
                actual = actual.Siguiente;
            }

            // Enlazar el nuevo nodo al final de la cadena
            actual.Siguiente = nuevo;
        }

        /// <summary>
        /// Busca y retorna un cliente por su número de identificación (cédula).
        /// Recorre la lista de principio a fin comparando el campo Identificacion.
        /// Retorna null si no se encuentra ninguno con ese ID.
        /// </summary>
        public Cliente BuscarPorIdentificacion(string identificacion)
        {
            NodoCliente actual = _cabeza;
            while (actual != null)
            {
                if (actual.Dato.Identificacion == identificacion)
                    return actual.Dato; // Encontrado: retornar el objeto Cliente
                actual = actual.Siguiente;
            }
            return null; // No se encontró
        }

        /// <summary>
        /// Busca y retorna un cliente por su número de cuenta bancaria.
        /// Se usa principalmente al deshacer transacciones (que solo guardan el número de cuenta).
        /// Retorna null si no existe esa cuenta.
        /// </summary>
        public Cliente BuscarPorNumeroCuenta(string numeroCuenta)
        {
            NodoCliente actual = _cabeza;
            while (actual != null)
            {
                if (actual.Dato.NumeroCuenta == numeroCuenta)
                    return actual.Dato;
                actual = actual.Siguiente;
            }
            return null;
        }

        /// <summary>
        /// Verifica si ya existe un cliente con la misma cédula O el mismo número de cuenta.
        /// Se llama antes de registrar para evitar duplicados en el sistema.
        /// Retorna true si alguno de los dos campos ya está registrado.
        /// </summary>
        public bool ExisteCliente(string identificacion, string numeroCuenta)
        {
            NodoCliente actual = _cabeza;
            while (actual != null)
            {
                if (actual.Dato.Identificacion == identificacion ||
                    actual.Dato.NumeroCuenta   == numeroCuenta)
                    return true; // Ya existe algún conflicto
                actual = actual.Siguiente;
            }
            return false; // Ningún conflicto encontrado
        }

        /// <summary>
        /// Recorre toda la lista imprimiendo cada cliente numerado.
        /// Usa el ToString() de la clase Cliente para mostrar los datos.
        /// </summary>
        public void ListarClientes()
        {
            if (_cabeza == null)
            {
                Console.WriteLine("  No hay clientes registrados.");
                return;
            }

            NodoCliente actual = _cabeza;
            int numero = 1;
            while (actual != null)
            {
                Console.WriteLine($"  {numero}. {actual.Dato}"); // ToString() del Cliente
                actual = actual.Siguiente;
                numero++;
            }
        }

        /// <summary>
        /// Cuenta cuántos nodos (clientes) hay en la lista recorriéndola entera.
        /// </summary>
        public int ContarClientes()
        {
            int contador = 0;
            NodoCliente actual = _cabeza;
            while (actual != null)
            {
                contador++;
                actual = actual.Siguiente;
            }
            return contador;
        }

        /// <summary>
        /// Suma el saldo de todos los clientes de la lista.
        /// Sirve para reportar el total de dinero que maneja el banco.
        /// </summary>
        public double TotalDinero()
        {
            double total = 0;
            NodoCliente actual = _cabeza;
            while (actual != null)
            {
                total += actual.Dato.Saldo;
                actual = actual.Siguiente;
            }
            return total;
        }

        /// <summary>
        /// Indica si la lista no tiene ningún cliente registrado.
        /// </summary>
        public bool EstaVacia()
        {
            return _cabeza == null;
        }
    }
}
