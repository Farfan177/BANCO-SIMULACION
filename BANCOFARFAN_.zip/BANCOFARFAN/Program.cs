using BancoSimulador.Logica;
using BancoSimulador.UI;

// ─────────────────────────────────────────────────────────────
//  SIMULADOR BÁSICO DE BANCO - ESTRUCTURAS DE DATOS
//  Lenguaje: C#  |  Tipo: Consola
//
//  Estructuras de datos utilizadas:
//    - Lista enlazada  → Gestión y almacenamiento de clientes
//    - Cola (FIFO)     → Atención por turnos (primero en llegar, primero en ser atendido)
//    - Pila (LIFO)     → Historial y reversión de transacciones (última operación se deshace primero)
//
//  Arquitectura:
//    Program.cs      → Punto de entrada. Crea el banco y lanza el menú.
//    Entidades/      → Clases de datos: Cliente, Transaccion, TipoTransaccion
//    Estructuras/    → Nodos y estructuras manuales: lista, cola, pila
//    Logica/         → Banco.cs: toda la lógica de negocio y validaciones
//    UI/             → Menu.cs: toda la interacción con el usuario por consola
// ─────────────────────────────────────────────────────────────

// Crear la instancia del banco con su nombre
Banco banco = new Banco("BANCO FARFAN");

// Crear el menú pasándole el banco (el menú no tiene lógica propia, solo llama al banco)
Menu menu = new Menu(banco);

// Iniciar el bucle principal del programa
menu.Ejecutar();
